import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Lock, AlertTriangle, ShieldCheck } from 'lucide-react';
import { supabase, SUPABASE_URL } from '../App';
import { AuraLogo } from './AuraLogo';

interface LoginModuleProps {
  onLoginSuccess: (organizationId: string) => void;
}

export default function LoginModule({ onLoginSuccess }: LoginModuleProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      if (SUPABASE_URL === 'https://mock-project.supabase.co') {
        // Mock success when no real Supabase is connected
        await new Promise(r => setTimeout(r, 1500));
        if (email && password) {
           onLoginSuccess('MOCK_ORG_ID');
           return;
        }
      }

      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      // Fetch organization profile
      if (data.user) {
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('organization_id')
          .eq('id', data.user.id)
          .single();

        if (profileError) {
          console.warn('[PROFILE_ERROR]', profileError);
          // Proceed anyway if profile fails but auth succeeded?
          // Or fail if organization is required
          // For now let's pass a mock one if missing, or use real one
          onLoginSuccess(profile?.organization_id || 'UNKNOWN_ORG');
        } else {
          onLoginSuccess(profile.organization_id);
        }
      }
    } catch (err: any) {
      console.error(err);
      let errMsg = err.message?.toUpperCase() || 'INVALID_CREDENTIALS';
      if (err.message && err.message.includes('Failed to fetch')) {
        errMsg = 'CONNECTION_REFUSED - CHECK_SUPABASE_URL';
      }
      setError(`[ACCESS_DENIED: ${errMsg}]`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-aura-bg text-aura-green font-mono flex items-center justify-center p-6 relative overflow-hidden select-none">
      <style dangerouslySetInnerHTML={{__html: `
        input:-webkit-autofill,
        input:-webkit-autofill:hover, 
        input:-webkit-autofill:focus, 
        input:-webkit-autofill:active {
            -webkit-box-shadow: 0 0 0 50px #050505 inset !important;
            -webkit-text-fill-color: #ffffff !important;
            transition: background-color 5000s ease-in-out 0s;
        }
      `}} />
      {/* Background Cyber Elements */}
      <div className="absolute inset-0 z-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at center, var(--color-aura-green) 1px, transparent 1px)', backgroundSize: '50px 50px' }}></div>
      <div className="absolute top-0 left-1/4 w-px h-full bg-gradient-to-b from-transparent via-aura-green to-transparent opacity-20"></div>
      <div className="absolute top-0 right-1/4 w-px h-full bg-gradient-to-b from-transparent via-aura-green to-transparent opacity-20"></div>

      <motion.div 
        initial={{ opacity: 0, y: 30, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="z-10 w-full max-w-3xl bg-aura-black border-4 border-aura-dark p-8 md:p-12 relative shadow-[0_0_50px_rgba(0,255,65,0.05)] text-base"
      >
        {/* Glow Effects */}
        <div className="absolute -inset-1 bg-aura-green/10 blur-xl opacity-50 z-[-1] pointer-events-none"></div>
        <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-aura-green"></div>
        <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-aura-green"></div>
        
        {/* Header */}
        <div className="flex flex-col items-center justify-center mb-12 gap-2 text-center">
          <AuraLogo size={80} className="text-aura-green drop-shadow-[0_0_15px_rgba(0,255,65,0.6)] mb-2" />
          <h1 className="text-3xl sm:text-4xl md:text-[45px] font-black tracking-widest uppercase text-aura-green shadow-black drop-shadow-lg leading-none flex items-center gap-3">
            AURA <span className="font-light">Play</span>
          </h1>
          <p className="text-sm md:text-base tracking-[0.15em] text-aura-green/80 uppercase mt-2">
            Smart Industry Solutions
          </p>
        </div>

        {/* Error Display */}
        {error && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="mb-8 border-2 border-aura-red bg-aura-red/10 p-4 flex items-center gap-4 text-aura-red font-bold text-lg"
          >
            <AlertTriangle size={24} className="shrink-0" />
            <span>{error}</span>
          </motion.div>
        )}

        {/* Login Form */}
        <form onSubmit={handleLogin} className="flex flex-col gap-8">
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2 opacity-70">
              <label className="text-lg uppercase tracking-widest font-bold">Email Address</label>
            </div>
            <div className="relative group">
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                placeholder="> ENTER_EMAIL"
                className="w-full bg-aura-bg border-4 border-aura-dark px-6 py-4 text-xl md:text-2xl text-aura-text outline-none focus:border-aura-green focus:shadow-[0_0_20px_rgba(0,255,65,0.2)] transition-all placeholder:text-aura-green/30"
              />
              <div className="absolute right-4 top-1/2 -translate-y-1/2 opacity-0 group-focus-within:opacity-100 text-aura-green transition-opacity">
                <div className="w-3 h-6 bg-aura-green animate-pulse"></div>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2 opacity-70">
              <label className="text-lg uppercase tracking-widest font-bold">Secret Key</label>
            </div>
            <div className="relative group">
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                placeholder="> ENTER_SECRET_KEY"
                className="w-full bg-aura-bg border-4 border-aura-dark px-6 py-4 text-xl md:text-2xl text-aura-text outline-none focus:border-aura-green focus:shadow-[0_0_20px_rgba(0,255,65,0.2)] transition-all placeholder:text-aura-green/30"
              />
              <div className="absolute right-4 top-1/2 -translate-y-1/2 opacity-0 group-focus-within:opacity-100 text-aura-green transition-opacity">
                <div className="w-3 h-6 bg-aura-green animate-pulse"></div>
              </div>
            </div>
          </div>

          <button 
            type="submit" 
            disabled={isLoading}
            className="mt-6 w-full border-4 border-aura-green bg-aura-green/10 py-6 text-2xl md:text-3xl font-black uppercase tracking-[0.2em] text-aura-text hover:bg-aura-green hover:text-black hover:shadow-[0_0_40px_rgba(0,255,65,0.6)] transition-all flex items-center justify-center gap-4 disabled:opacity-50 disabled:pointer-events-none group"
          >
            {isLoading ? (
              <span className="animate-pulse flex items-center gap-3">
                <ShieldCheck className="animate-spin" size={32} />
                AUTHENTICATING...
              </span>
            ) : (
              <>
                <Lock size={32} className="group-hover:hidden" />
                <span className="group-hover:hidden">[INITIATE_HANDSHAKE]</span>
                <span className="hidden group-hover:block">[CONFIRM_CONNECTION]</span>
              </>
            )}
          </button>
        </form>
        
        {/* Decorative elements */}
        <div className="mt-12 pt-6 border-t-[1px] border-dashed border-aura-dark flex justify-between items-center text-sm opacity-50">
           <span>v1.0.0</span>
           <span className="uppercase tracking-widest">Command Center</span>
        </div>
      </motion.div>
    </div>
  );
}
