/// <reference types="vite/client" />
import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Activity, AlertTriangle, Monitor, Cpu, Server, Play, Copy, Maximize2, Crosshair, Map, X, Clock, Pencil, Users, Wifi, UserPlus, Trophy, Fingerprint, RefreshCw, Settings, ChevronLeft, ChevronRight } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { createClient } from '@supabase/supabase-js';
import { EventHorizon, SystemEvent } from './components/EventHorizon';

// Mock Supabase client - real environment variables should be used in production
export const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || 'https://mock-project.supabase.co';
export const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || 'mock-key';
export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

/* --- TYPES & MOCK DATA --- */
export type TableStatus = 'online' | 'alert' | 'promo' | 'offline' | 'admin';
export interface TableData {
  id: string;
  name: string;
  status: TableStatus;
  staffId: string | null;
  lastPing: number;
}

export interface StaffData {
  id: string;
  name: string;
  nfcUid: string | null;
  rating: number;
  tables: string[];
}

const INITIAL_STAFF: StaffData[] = [];

const INITIAL_EVENTS: SystemEvent[] = [];

const INITIAL_TABLES: TableData[] = [
  { id: 'TBL-01', name: 'T01', status: 'online', staffId: null, lastPing: Date.now() },
  { id: 'TBL-02', name: 'T02', status: 'online', staffId: null, lastPing: Date.now() },
  { id: 'TBL-03', name: 'T03', status: 'online', staffId: null, lastPing: Date.now() }
];

import SandboxModule from './components/SandboxModule';
import LoginModule from './components/LoginModule';
import { AuraLogo } from './components/AuraLogo';
import { TacticalGrid } from './components/TacticalGrid';
import { CreativeLab } from './components/CreativeLab';
import { Orchester } from './components/Orchester';
import { StaffManagement } from './components/StaffManagement';

/* --- MAIN COMPONENT --- */
export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [organizationId, setOrganizationId] = useState<string | null>(null);
  
  const [activeTab, setActiveTab] = useState<'grid' | 'lab' | 'orchester' | 'staff' | 'sandbox'>('grid');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  
  const [tables, setTables] = useState<TableData[]>(INITIAL_TABLES);
  const [staffList, setStaffList] = useState<StaffData[]>(INITIAL_STAFF);
  const [selectedTableId, setSelectedTableId] = useState<string | null>(null);
  const [tableToDelete, setTableToDelete] = useState<string | null>(null);
  const [systemEvents, setSystemEvents] = useState<SystemEvent[]>(INITIAL_EVENTS);
  
  // Orchester Gamification State
  const [winningRatio, setWinningRatio] = useState(50);
  const [flashCountdown, setFlashCountdown] = useState<number | null>(null);
  
  



  // Flash Countdown Logic
  useEffect(() => {
    if (flashCountdown !== null && flashCountdown > 0) {
      const t = setTimeout(() => setFlashCountdown(flashCountdown - 1), 1000);
      return () => clearTimeout(t);
    } else if (flashCountdown === 0) {
      setFlashCountdown(null);
      // Revert promo tables
      setTables(prev => prev.map(t => t.status === 'promo' ? { ...t, status: 'online' } : t));
    }
  }, [flashCountdown]);



  const handleAddTable = () => {
    const newId = `TBL-${String(tables.length + 1).padStart(2, '0')}`;
    const newTable: TableData = {
      id: newId,
      name: `T${String(tables.length + 1).padStart(2, '0')}`,
      status: 'offline',
      staffId: null,
      lastPing: Date.now()
    };
    setTables(prev => [...prev, newTable]);
  };

  const handleRemoveTable = (id: string) => {
    setTableToDelete(id);
  };

  const confirmRemoveTable = () => {
    if (!tableToDelete) return;
    setTables(prev => prev.filter(t => t.id !== tableToDelete));
    if (selectedTableId === tableToDelete) setSelectedTableId(null);
    setTableToDelete(null);
  };

  const handleRenameTable = (id: string, newName: string) => {
    setTables(prev => prev.map(t => t.id === id ? { ...t, name: newName } : t));
  };

  if (!isAuthenticated) {
    return (
      <LoginModule 
        onLoginSuccess={(orgId) => {
          setOrganizationId(orgId);
          setIsAuthenticated(true);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen h-screen bg-aura-panel text-aura-green font-mono flex flex-col overflow-hidden p-[18px] border-4 border-aura-dark select-none">
      
      {/* Top Bar - Telemetry & Status */}
      <header className="flex justify-between items-center border-b-2 border-aura-green/30 pb-4 mb-[18px] shrink-0 z-10">
        <div className="flex items-center gap-[26px]">
          <div className="flex items-center gap-4">
            <AuraLogo size={42} className="text-aura-green drop-shadow-[0_0_10px_rgba(0,255,65,0.6)]" />
            <div className="flex flex-col">
              <h1 className="text-[24px] font-black tracking-widest uppercase text-aura-green leading-none flex items-center gap-2">
                AURA <span className="font-light">Play</span>
              </h1>
              <span className="text-[12px] text-aura-cyan uppercase tracking-widest mt-1">Command Center</span>
            </div>
          </div>
          <div className="h-10 w-[2px] bg-aura-dark"></div>
        </div>
        
        <div className="flex items-center gap-[18px]">
          <div className="flex gap-[35px] text-right items-center">
            <div className="flex flex-col">
              <span className="text-[12px] opacity-50 uppercase">Sys Time</span>
              <span className="text-[15px] text-aura-text">{new Date().toLocaleTimeString('en-US', { hour12: false })}</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[12px] opacity-50 uppercase">Sync Status</span>
              <span className="text-[15px] text-aura-cyan">READY</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Layout Area */}
      <div className="flex flex-1 overflow-hidden gap-[18px]">
        
        {/* Left Sidebar Navigation */}
        <aside className={`${isSidebarCollapsed ? 'w-20 items-center' : 'w-64 p-[18px]'} bg-aura-panel border-2 border-aura-dark flex flex-col shrink-0 z-10 transition-all duration-300 relative`}>
          {isSidebarCollapsed ? (
            <div className="py-4 w-full flex justify-center">
              <button onClick={() => setIsSidebarCollapsed(false)} className="text-aura-green opacity-60 hover:opacity-100 transition-opacity p-[9px]">
                <ChevronRight size={16} />
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-between mb-[18px]">
              <h2 className="text-[13px] font-bold flex items-center gap-[9px]">
                <span className="w-1 h-3 bg-aura-cyan"></span>
                MODULE TERMINAL
              </h2>
              <button onClick={() => setIsSidebarCollapsed(true)} className="text-aura-green opacity-60 hover:opacity-100 transition-opacity">
                <ChevronLeft size={16} />
              </button>
            </div>
          )}

          <div className={`space-y-2 w-full ${isSidebarCollapsed ? 'px-2' : ''}`}>
            <NavButton 
              active={activeTab === 'grid'} 
              onClick={() => setActiveTab('grid')} 
              icon={<Map size={16} />} 
              label="Tactical Grid"
              collapsed={isSidebarCollapsed}
            />
            <NavButton 
              active={activeTab === 'lab'} 
              onClick={() => setActiveTab('lab')} 
              icon={<Cpu size={16} />} 
              label="Creative Lab" 
              collapsed={isSidebarCollapsed}
            />
            <NavButton 
              active={activeTab === 'orchester'} 
              onClick={() => setActiveTab('orchester')} 
              icon={<Crosshair size={16} />} 
              label="Orchester" 
              collapsed={isSidebarCollapsed}
            />
            <NavButton 
              active={activeTab === 'sandbox'} 
              onClick={() => setActiveTab('sandbox')} 
              icon={<Settings size={16} />} 
              label="Sandbox" 
              collapsed={isSidebarCollapsed}
            />
            <NavButton 
              active={activeTab === 'staff'} 
              onClick={() => setActiveTab('staff')} 
              icon={<Users size={16} />} 
              label="Staff & NFC" 
              collapsed={isSidebarCollapsed}
            />
          </div>

          <div className={`mt-auto w-full ${isSidebarCollapsed ? 'pb-4 px-2' : ''}`}>
            <div className={`bg-aura-inner border-l-2 border-aura-green ${isSidebarCollapsed ? 'p-[9px] flex flex-col items-center justify-center gap-[9px]' : 'p-[14px]'}`}>
              {isSidebarCollapsed ? (
                <>
                  <div className="flex flex-col items-center justify-center relative group">
                    <Trophy size={14} className="text-aura-green opacity-60 mb-1" />
                    <span className="text-[12px] text-aura-text font-bold">{winningRatio}%</span>
                    <div className="absolute left-full top-1/2 -translate-y-1/2 ml-4 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity z-50 px-2 py-1 bg-aura-black border border-aura-green/50 text-aura-green font-mono text-[12px] uppercase font-bold tracking-widest shadow-[0_0_10px_rgba(0,255,65,0.2)] whitespace-nowrap">
                      Win Ratio
                    </div>
                  </div>
                  <div className="w-8 h-[1px] bg-aura-dark my-1"></div>
                  <div className="flex flex-col items-center justify-center relative group">
                    <Activity size={14} className="text-aura-cyan opacity-60 mb-1" />
                    <span className="text-[12px] text-aura-cyan font-bold leading-none">{flashCountdown !== null ? flashCountdown : '-'}</span>
                    <div className="absolute left-full top-1/2 -translate-y-1/2 ml-4 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity z-50 px-2 py-1 bg-aura-black border border-aura-cyan/50 text-aura-cyan font-mono text-[12px] uppercase font-bold tracking-widest shadow-[0_0_10px_rgba(0,229,255,0.2)] whitespace-nowrap">
                      Flash Countdown
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <p className="text-[12px] opacity-60 uppercase mb-1">Sys Gamification</p>
                  <div className="text-[15px] text-aura-text flex items-center justify-between">
                    <span>Win Ratio:</span>
                    <span className="font-bold">{winningRatio}%</span>
                  </div>
                  <div className="text-[13px] text-aura-cyan mt-1 flex items-center justify-between">
                    <span>Flash:</span>
                    <span>{flashCountdown !== null ? `${flashCountdown}s` : 'Standby'}</span>
                  </div>
                </>
              )}
            </div>
          </div>
        </aside>

        {/* Dynamic Content Pane */}
        <main className="flex-1 bg-aura-panel border-2 border-aura-dark p-[18px] relative overflow-hidden flex flex-col">
          <AnimatePresence mode="wait">
            {activeTab === 'grid' && (
              <motion.div 
                key="grid"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="w-full h-full p-[26px] overflow-y-auto"
              >
                <TacticalGrid 
                  tables={tables} 
                  staffList={staffList}
                  onTableSelect={(id) => setSelectedTableId(id)} 
                  onAddTable={handleAddTable}
                  onRemoveTable={handleRemoveTable}
                />
              </motion.div>
            )}
            
            {activeTab === 'lab' && (
              <motion.div 
                key="lab"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0 }}
                className="w-full h-full p-[26px] overflow-y-auto"
              >
                <CreativeLab />
              </motion.div>
            )}
            
            {activeTab === 'orchester' && (
              <motion.div 
                key="orchester"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="w-full h-full p-[26px] overflow-y-auto"
              >
                <Orchester 
                  tables={tables} 
                  winningRatio={winningRatio}
                  setWinningRatio={setWinningRatio}
                  onFlashAction={() => {
                    setFlashCountdown(15);
                    setTables(prev => prev.map(t => ({ ...t, status: 'promo' })));
                  }}
                  isFlashActive={flashCountdown !== null}
                  flashTime={flashCountdown}
                />
              </motion.div>
            )}
            {activeTab === 'staff' && (
              <motion.div 
                key="staff"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="w-full h-full p-[26px] overflow-y-auto"
              >
                <StaffManagement 
                  staffList={staffList} 
                  setStaffList={setStaffList} 
                  tables={tables}
                />
              </motion.div>
            )}

            {activeTab === 'sandbox' && (
              <motion.div 
                key="sandbox"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="w-full h-full overflow-hidden"
              >
                <SandboxModule />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Live Mirroring Drawer (Always available across tabs when a table is selected) */}
          <AnimatePresence>
            {selectedTableId && (
              <>
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="absolute inset-0 z-40 bg-black/50 backdrop-blur-sm"
                  onClick={() => setSelectedTableId(null)}
                />
                <LiveMirrorDrawer 
                  table={tables.find(t => t.id === selectedTableId)} 
                  staff={staffList.find(s => s.id === tables.find(t => t.id === selectedTableId)?.staffId)}
                  onClose={() => setSelectedTableId(null)} 
                  onRename={(name) => {
                    if (selectedTableId) {
                      handleRenameTable(selectedTableId, name);
                    }
                  }}
                  onToggleAdmin={(id, isCurrentlyAdmin) => {
                    setTables(prev => prev.map(t => t.id === id ? { ...t, status: isCurrentlyAdmin ? 'online' : 'admin' } : t));
                  }}
                />
              </>
            )}
          </AnimatePresence>
          
        </main>
        <EventHorizon 
          events={systemEvents} 
          onSelectUnit={(id) => {
             setActiveTab('grid');
             setSelectedTableId(id);
          }} 
          activeNodesCount={tables.filter(t => t.status !== 'offline').length}
          totalNodesCount={tables.length}
        />
      </div>
      
      {/* Footer: Global Status */}
      <footer className="mt-[18px] pt-2 border-t border-aura-dark flex justify-between items-center text-[12px] opacity-60 shrink-0">
        <div className="flex gap-[26px]">
          <span>DB: NOT_CONNECTED</span>
          <span>LATENCY: N/A</span>
        </div>
      </footer>

      {/* Confirmation Modal */}
      <AnimatePresence>
        {tableToDelete && (
          <ConfirmModal 
            title="Confirm Node Deletion" 
            message={`Are you sure you want to permanently delete ${tableToDelete}?`} 
            onConfirm={confirmRemoveTable} 
            onCancel={() => setTableToDelete(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function LiveMirrorDrawer({ table, staff, onClose, onRename, onToggleAdmin }: { table?: TableData, staff?: StaffData, onClose: () => void, onRename: (name: string) => void, onToggleAdmin: (id: string, isAdmin: boolean) => void }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState('');

  useEffect(() => {
    if (table && !isEditing) {
      setEditName(table.name);
    }
  }, [table?.name, isEditing]);

  useEffect(() => {
    setIsEditing(false);
  }, [table?.id]);

  if (!table) return null;

  const submitEdit = () => {
    setIsEditing(false);
    if (editName.trim() !== '' && editName !== table.name) {
      onRename(editName.trim().toUpperCase());
    } else {
      setEditName(table.name);
    }
  };

  return (
    <motion.div
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className="absolute top-0 right-0 bottom-0 w-[400px] border-l border-aura-green/30 bg-aura-bg/95 backdrop-blur-xl shadow-[-10px_0_30px_rgba(0,0,0,0.8)] z-50 flex flex-col"
    >
      <div className="flex items-center justify-between p-[18px] border-b border-aura-green/20">
        <div className="flex items-center gap-[14px] text-aura-green">
          <Maximize2 size={18} />
          <h3 className="font-bold uppercase tracking-widest">Live Mirroring</h3>
        </div>
        <button onClick={onClose} className="text-aura-green/50 hover:text-aura-green transition-colors">
          <X size={20} />
        </button>
      </div>

      <div className="p-[26px] flex-1 flex flex-col overflow-y-auto">
        <div className="flex items-start justify-between mb-6 gap-4">
          <div className="flex-1 min-w-0">
            <div className="text-[33px] font-black tracking-widest text-glow-green text-aura-green mb-1 flex items-center gap-[14px]">
              {isEditing ? (
                <input
                  autoFocus
                  value={editName}
                  onChange={e => setEditName(e.target.value)}
                  onBlur={submitEdit}
                  onKeyDown={e => {
                    if (e.key === 'Enter') submitEdit();
                    if (e.key === 'Escape') { setIsEditing(false); setEditName(table.name); }
                  }}
                  className="bg-transparent border-b border-aura-cyan text-aura-text outline-none w-48 text-[33px] font-black tracking-widest"
                  maxLength={10}
                />
              ) : (
                <>
                  <span className="truncate">{table.name}</span>
                  <button onClick={() => setIsEditing(true)} className="text-aura-cyan hover:text-aura-text transition-colors opacity-60 hover:opacity-100 flex-shrink-0">
                    <Pencil size={18} />
                  </button>
                </>
              )}
            </div>
            <div className="text-[13px] uppercase text-aura-green/60 flex flex-wrap gap-2 mt-[9px]">
              <span className="flex items-center gap-1 whitespace-nowrap"><Monitor size={12}/> {table.id}</span>
              <span className="text-aura-green/30">•</span>
              <span className="flex items-center gap-1 whitespace-nowrap">
                <Users size={12} className={staff ? "text-aura-cyan" : ""} /> 
                {staff?.name || 'UNASSIGNED'}
              </span>
              {staff && (
                <>
                  <span className="text-aura-green/30">•</span>
                  <span className="flex items-center gap-1 text-yellow-500 whitespace-nowrap">
                    <Trophy size={12} /> {staff.rating.toFixed(1)}
                  </span>
                </>
              )}
            </div>
          </div>
          <div className="flex flex-col items-end gap-[9px] flex-shrink-0">
            <div className="px-3 py-1 border-2 border-aura-green text-aura-green text-[12px] uppercase tracking-widest glow-green animate-pulse whitespace-nowrap">
              Receiving Stream
            </div>
            <button 
              onClick={() => onToggleAdmin(table.id, table.status === 'admin')}
              className={`px-3 py-1 border text-[12px] uppercase tracking-widest transition-colors whitespace-nowrap ${table.status === 'admin' ? 'border-purple-500 bg-purple-500/20 text-purple-400' : 'border-aura-dark text-aura-green/50 hover:border-purple-500/50 hover:text-purple-400'}`}
            >
              {table.status === 'admin' ? 'Exit Admin Mode' : 'Enter Admin Mode'}
            </button>
          </div>
        </div>

        {/* 16:9 Mirror Screen */}
        <div className="w-full aspect-video border-2 border-aura-green/50 relative bg-aura-black flex items-center justify-center overflow-hidden flex-shrink-0">
           <div className="absolute top-2 left-2 text-[12px] text-aura-green/40">fps: 59.9 latency: 12ms</div>
           <div className="absolute inset-0 bg-gradient-to-b from-transparent to-aura-green/5 pointer-events-none" />
           
           {/* Mock Screen Content based on Status */}
           {table.status === 'online' && (
             <div className="text-aura-green/30 text-[22px] font-bold tracking-widest flex items-center gap-[9px]"><Play /> STANDBY SCREEN</div>
           )}
           {table.status === 'admin' && (
             <div className="absolute inset-0 bg-purple-500/10 flex items-center justify-center flex-col text-purple-400 border-2 border-purple-500">
               <div className="absolute -inset-10 bg-[conic-gradient(from_0deg,transparent_0deg,transparent_270deg,rgba(168,85,247,0.3)_360deg)] animate-[spin_3s_linear_infinite] pointer-events-none" />
               <Cpu size={48} className="mb-[18px]" />
               <div className="text-[26px] font-black tracking-widest mb-[9px] shadow-[0_0_15px_rgba(168,85,247,0.5)]">ADMIN DIAGNOSTICS</div>
               <div className="text-[13px] uppercase opacity-80">Device Configuration Unlocked</div>
             </div>
           )}
           {table.status === 'alert' && (
             <div className="absolute inset-0 bg-aura-red/20 flex items-center justify-center text-aura-red font-black text-[26px] tracking-widest animate-pulse border-4 border-aura-red">
               <AlertTriangle className="mr-2" /> SYSTEM ALERT
             </div>
           )}
           {table.status === 'promo' && (
             <div className="absolute inset-0 bg-aura-cyan/10 flex items-center justify-center flex-col text-aura-cyan">
               <div className="text-[33px] font-black italic tracking-widest mb-[9px] text-glow-cyan">MEGA JACKPOT</div>
               <div className="text-[22px]">$5,000.00</div>
             </div>
           )}
        </div>

        <div className="mt-8 mb-[48px] grid grid-cols-2 gap-[18px]">
          <StatBox label="Signal Str" value="98%" />
          <StatBox label="Last Ping" value="0.2s" />
          <StatBox label="Uptime" value="128:44" />
          <StatBox label="Errors (24h)" value="0" />
        </div>

        <button className="mt-auto w-full py-4 bg-aura-green/10 border-2 border-aura-green text-aura-green border-dashed hover:bg-aura-green/20 transition-colors uppercase text-[13px] font-bold tracking-widest">
          Initiate Remote Reboot
        </button>
      </div>
    </motion.div>
  );
}

/* --- REUSABLE UI COMPONENTS --- */
function NavButton({ active, onClick, icon, label, collapsed }: any) {
  return (
    <div className="relative group w-full">
      <button 
        onClick={onClick}
        className={`w-full flex items-center ${collapsed ? 'justify-center p-[14px]' : 'gap-[14px] p-[14px]'} text-[13px] font-bold transition-all border-l-2 ${
          active 
            ? 'border-aura-green bg-aura-inner text-aura-text' 
            : 'border-transparent text-aura-green/60 hover:text-aura-text hover:bg-aura-dark'
        }`}
      >
        {icon}
        {!collapsed && <span className="uppercase">{label}</span>}
      </button>
      {collapsed && (
        <div className="absolute left-full top-1/2 -translate-y-1/2 ml-2 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity z-50 px-2 py-1 bg-aura-black border border-aura-green/50 text-aura-green font-mono text-[12px] uppercase font-bold tracking-widest shadow-[0_0_10px_rgba(0,255,65,0.2)] whitespace-nowrap">
          {label}
        </div>
      )}
    </div>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-[12px] text-aura-green/50 uppercase tracking-[0.2em] mb-[18px] border-b border-aura-green/10 pb-2">
      {children}
    </div>
  );
}

function StatBox({ label, value }: { label: string, value: string }) {
  return (
    <div className="border-2 border-aura-green/20 p-[14px] bg-aura-green/5">
      <div className="text-[12px] uppercase text-aura-green/50 mb-1">{label}</div>
      <div className="text-[15px] font-bold text-aura-green">{value}</div>
    </div>
  );
}

function ConfirmModal({ title, message, onConfirm, onCancel }: { title: string, message: string, onConfirm: () => void, onCancel: () => void }) {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-aura-black/80 backdrop-blur-sm">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-aura-panel border-2 border-aura-red p-[26px] max-w-md w-full shadow-[0_0_20px_rgba(255,0,60,0.2)]"
      >
        <div className="flex items-center gap-[14px] text-aura-red mb-[18px] border-b border-aura-red/30 pb-3">
          <AlertTriangle className="animate-pulse" />
          <h2 className="font-bold uppercase tracking-widest text-glow-red">{title}</h2>
        </div>
        <p className="text-aura-text text-[15px] mb-6 font-mono">{message}</p>
        <div className="flex gap-[18px]">
          <button 
            onClick={onCancel}
            className="flex-1 py-2 border-2 border-aura-dark text-aura-green/60 hover:text-aura-text hover:bg-aura-inner uppercase text-[13px] font-bold tracking-widest transition-colors"
          >
            Cancel
          </button>
          <button 
            onClick={onConfirm}
            className="flex-1 py-2 bg-aura-red/20 border-2 border-aura-red text-aura-red hover:bg-aura-red hover:text-aura-text uppercase text-[13px] font-bold tracking-widest transition-colors"
          >
            Confirm Delete
          </button>
        </div>
      </motion.div>
    </div>
  );
}

