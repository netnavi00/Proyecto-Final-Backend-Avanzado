import fetch from 'node-fetch';
const urls = [
  'https://upload.wikimedia.org/wikipedia/commons/4/4c/A_glass_of_beer.jpg',
  'https://upload.wikimedia.org/wikipedia/commons/0/0b/Beer_mug.jpg',
  'https://upload.wikimedia.org/wikipedia/commons/1/15/Buffalo_wings%2C_celery%2C_and_blue_cheese_dip_-_20050810.jpg',
  'https://upload.wikimedia.org/wikipedia/commons/f/ff/Fried_chicken_wings.jpg',
  'https://upload.wikimedia.org/wikipedia/commons/2/23/Spicy_wings.jpg'
];
async function check() {
  for (const url of urls) {
    try {
      const res = await fetch(url);
      console.log(url, res.status);
    } catch(err) {
      console.log(url, 'error');
    }
  }
}
check();
