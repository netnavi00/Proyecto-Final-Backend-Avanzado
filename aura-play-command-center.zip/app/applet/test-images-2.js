const urls = [
  'https://images.unsplash.com/photo-1566412140410-d023af14d7a8',
  'https://images.unsplash.com/photo-1604908176997-125f25cc6f3d',
  'https://images.unsplash.com/photo-1566633661262-1065e9d99723',
  'https://images.unsplash.com/photo-1563514995221-825dfb426914',
  'https://images.unsplash.com/photo-1569691105775-6fec0cb4aed7',
  'https://images.unsplash.com/photo-1497034825429-c343d7c6a68f',
  'https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8',
  'https://images.unsplash.com/photo-1492684223066-81342ee5ff30'
];

async function test() {
  for (const url of urls) {
    try {
      const res = await fetch(url);
      console.log(url, res.status);
    } catch (e) {
      console.log(url, 'Error');
    }
  }
}
test();
