import fs from 'fs';

const files = ['src/App.tsx', 'src/components/SandboxModule.tsx', 'src/components/EventHorizon.tsx'];

files.forEach(file => {
  if (!fs.existsSync(file)) return;
  let content = fs.readFileSync(file, 'utf-8');

  // Bump large text
  content = content.replace(/\btext-lg\b/g, 'text-[20px]'); // originally 18px
  content = content.replace(/\btext-xl\b/g, 'text-[22px]'); // originally 20px
  content = content.replace(/\btext-2xl\b/g, 'text-[26px]'); // originally 24px
  content = content.replace(/\btext-3xl\b/g, 'text-[33px]'); // originally 30px
  content = content.replace(/\btext-4xl\b/g, 'text-[40px]'); // originally 36px

  fs.writeFileSync(file, content);
});

console.log("Bumped large text");
