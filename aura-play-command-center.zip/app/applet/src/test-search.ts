async function searchTokens(query: string) {
  const res = await fetch(`https://unsplash.com/s/photos/${query}`);
  const html = await res.text();
  const matches = [...html.matchAll(/images\.unsplash\.com\/photo-[a-zA-Z0-9\-]+/g)];
  return [...new Set(matches.map(m => m[0]))].slice(0, 5);
}
async function run() {
  console.log('beer', await searchTokens('beer'));
  console.log('wings', await searchTokens('chicken-wings'));
  console.log('stout', await searchTokens('stout'));
}
run();
